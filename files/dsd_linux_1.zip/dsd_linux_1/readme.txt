Defense Station Desktopable
20 Wave Demo version of Defense Station Touchable for iPhone.

see http://www.ironshod.co.nz for details :-)

Built on Kubuntu 8.10, sorry if it doesn't work on your linux.
Try the windows version in wine ;-)

-danzel